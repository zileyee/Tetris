# Tetris Game

## Game Instruction

The controls of this game is very simple.

- `W` to rotate the block
- `A` to move left
- `S` to move down
- `D` to move right
- `Space` to drop to bottom
- `R` to restart the game